//for loop program to print even numbers between 2-10

class even_numbers{  
public static void main(String[] args) {  
    
    for(int n=2;n<=10;n+=2){  
        System.out.println(n);  
    }  
}  
}  