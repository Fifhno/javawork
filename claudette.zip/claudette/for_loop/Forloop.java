//for loop program to print numbers from 1-10 
public class Forloop{  
public static void main(String[] args) {  
    
    for(int n=1;n<=10;n++){  
        System.out.println(n);  
    }  
}  
}  