// program to print fruit types

class hospital{  
void  center(){System.out.println("hospital has many supporting health center");}  
}  
class healthcenter extends hospital{  
void health(){System.out.println("health center supports hospital");}  
}  
class hospitals{  
public static void main(String args[]){  
healthcenter d=new healthcenter();  
d.center();  
d.health();  
 
}}  