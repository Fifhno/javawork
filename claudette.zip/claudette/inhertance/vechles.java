// program to show inheritance of a mother and a child

class vehicle{  
void  behavior(){System.out.println("vehicles move");}  
}  
class car extends vehicle{  
void vehiclemember(){System.out.println("since car is among vehicles it can also move");}  
}  
class vechles{  
public static void main(String args[]){  
car d=new car();  
d.behavior();  
d.vehiclemember();  
 
}}  