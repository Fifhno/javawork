//java object and class
// program to access doctor data by using object

class bachelorstudent{
 int id=12554;
 String name="mugabo"; 
  String department="HRM";
}
class studentdata{  
   
 public static void main(String args[]){  

  bachelorstudent d=new bachelorstudent(); 
  System.out.println("bachelorstudent information"); 
  System.out.println("***************************"); 
  System.out.println(); 
  System.out.println("bachelorstudent id is: "+d.id);  
  System.out.println("bachelorstudent name is: "+d.name);  
  System.out.println("bachelorstudent departiment: "+d.department); 
 }  
}  
