 //division with overloaded methods in java

class division{  
  void divide(int a,int b){System.out.println(a/b);}  
  void divide(int a,int b,int c){System.out.println(a/b/c);}  
  
  public static void main(String args[]){  
 division obj=new division();  
  obj.divide(60,3);
  obj.divide(60,3,2);  
  
  }  
}  